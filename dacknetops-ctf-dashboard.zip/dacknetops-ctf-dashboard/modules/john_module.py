"""
modules/john_module.py
-----------------------
Thin, logged wrapper around John the Ripper for cracking hash files you
already own (e.g. a shadow file or hash dump pulled from your own lab VM
during an authorized exercise). John doesn't take a network target, so
there's no host to scope-check here — the safety boundary is simply
"you uploaded this file yourself."
"""

import shutil
import subprocess

import config
from modules import audit_log


def is_installed() -> bool:
    return shutil.which(config.JOHN_BIN) is not None


def run_crack(hash_file_path: str, wordlist_path: str | None, format_hint: str | None):
    """
    Run John the Ripper against an uploaded hash file.

    Returns (success: bool, output: str).
    """
    if not is_installed():
        return False, (
            f"'{config.JOHN_BIN}' is not installed or not on PATH. "
            "Install John the Ripper on this lab machine first "
            "(see README.md)."
        )

    cmd = [config.JOHN_BIN]
    if format_hint:
        cmd.append(f"--format={format_hint}")
    if wordlist_path:
        cmd.append(f"--wordlist={wordlist_path}")
    cmd.append(hash_file_path)

    audit_log.log("JOHN_RUN", f"cmd={' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=600
        )
        # Pull cracked results with --show for a clean summary
        show = subprocess.run(
            [config.JOHN_BIN, "--show", hash_file_path],
            capture_output=True, text=True, timeout=60,
        )
        output = result.stdout + "\n" + result.stderr + "\n\n--show output--\n" + show.stdout
        audit_log.log("JOHN_DONE", f"returncode={result.returncode}")
        return True, output
    except subprocess.TimeoutExpired:
        audit_log.log("JOHN_TIMEOUT", hash_file_path)
        return False, "John the Ripper run timed out after 10 minutes."
    except Exception as exc:  # noqa: BLE001
        audit_log.log("JOHN_ERROR", str(exc))
        return False, f"Error running John the Ripper: {exc}"
