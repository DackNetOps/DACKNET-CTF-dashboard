"""
modules/safety.py
------------------
The safety gate. Every module (john, medusa, mitm) calls
`assert_authorized_target()` before it is allowed to touch anything.

This is deliberately the ONLY path to running an external tool — there is
no other function anywhere in this project that shells out to john,
medusa, or scapy. If you are reading this to understand how the scope
restriction works, this file is the whole story.
"""

import ipaddress
import json
import socket

import config


class OutOfScopeError(Exception):
    """Raised when a requested target is not inside the lab whitelist."""


def _load_extra_targets():
    """Read user-added lab networks from lab_data/lab_targets.json, if present."""
    if config.LAB_TARGETS_FILE.exists():
        try:
            data = json.loads(config.LAB_TARGETS_FILE.read_text())
            return data.get("networks", [])
        except (json.JSONDecodeError, OSError):
            return []
    return []


def allowed_networks():
    """Full list of CIDR ranges this dashboard is permitted to act against."""
    return list(config.LAB_ALLOWED_NETWORKS) + _load_extra_targets()


def _resolve(host):
    """Resolve a hostname to an IP. Returns None if resolution fails."""
    try:
        return socket.gethostbyname(host)
    except socket.gaierror:
        return None


def assert_authorized_target(host: str, confirmed_by_user: bool):
    """
    Raise OutOfScopeError unless `host` resolves inside one of the lab
    networks AND the user explicitly checked the "I own/am authorized to
    test this target" box in the form.

    Both conditions are required. Neither one alone is enough.
    """
    if not confirmed_by_user:
        raise OutOfScopeError(
            "You must confirm you own this target or have written "
            "authorization to test it before any tool can run."
        )

    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        resolved = _resolve(host)
        if resolved is None:
            raise OutOfScopeError(f"Could not resolve host '{host}'.")
        ip = ipaddress.ip_address(resolved)

    for net in allowed_networks():
        try:
            if ip in ipaddress.ip_network(net, strict=False):
                return ip
        except ValueError:
            continue

    raise OutOfScopeError(
        f"'{host}' ({ip}) is outside the configured lab scope "
        f"({', '.join(allowed_networks())}). Add your lab subnet to "
        f"lab_data/lab_targets.json if this is a range you control."
    )
