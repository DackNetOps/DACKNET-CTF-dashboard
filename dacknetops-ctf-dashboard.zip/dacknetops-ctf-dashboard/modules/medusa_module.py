"""
modules/medusa_module.py
-------------------------
Thin, logged wrapper around Medusa for login brute-force exercises
against YOUR OWN lab services (e.g. an SSH or FTP service you stood up
on a Metasploitable-style VM for practice).

Every call goes through modules.safety.assert_authorized_target() before
a single subprocess is spawned. If the target isn't inside your
configured lab ranges, this refuses to run — there is no bypass flag.
"""

import shutil
import subprocess

import config
from modules import audit_log, safety


def is_installed() -> bool:
    return shutil.which(config.MEDUSA_BIN) is not None


def run_bruteforce(
    host: str,
    service: str,
    user_file_path: str,
    pass_file_path: str,
    confirmed_by_user: bool,
    threads: int = 4,
):
    """
    Run Medusa against a single host/service using provided user & password
    lists. Returns (success: bool, output: str).
    """
    # --- the one and only gate ---------------------------------------
    try:
        safety.assert_authorized_target(host, confirmed_by_user)
    except safety.OutOfScopeError as exc:
        audit_log.log("MEDUSA_BLOCKED", f"host={host} reason={exc}")
        return False, f"Blocked: {exc}"

    if not is_installed():
        return False, (
            f"'{config.MEDUSA_BIN}' is not installed or not on PATH. "
            "Install Medusa on this lab machine first (see README.md)."
        )

    threads = max(1, min(threads, 8))  # keep it sane for a lab box

    cmd = [
        config.MEDUSA_BIN,
        "-h", host,
        "-U", user_file_path,
        "-P", pass_file_path,
        "-M", service,
        "-t", str(threads),
    ]

    audit_log.log("MEDUSA_RUN", f"host={host} service={service} threads={threads}")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        output = result.stdout + "\n" + result.stderr
        audit_log.log("MEDUSA_DONE", f"host={host} returncode={result.returncode}")
        return True, output
    except subprocess.TimeoutExpired:
        audit_log.log("MEDUSA_TIMEOUT", host)
        return False, "Medusa run timed out after 15 minutes."
    except Exception as exc:  # noqa: BLE001
        audit_log.log("MEDUSA_ERROR", str(exc))
        return False, f"Error running Medusa: {exc}"
