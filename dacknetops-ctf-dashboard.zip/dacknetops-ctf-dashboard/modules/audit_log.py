"""
modules/audit_log.py
---------------------
Every action taken by every tool module is written here, success or
failure. For a lab dashboard that touches cracking/brute-force/MITM
tooling, a plain-text trail of "who ran what, against what, when" is not
optional — it's the first thing worth having before anything else.
"""

import datetime

import config


def log(event: str, detail: str = ""):
    config.AUDIT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().isoformat(timespec="seconds")
    line = f"[{timestamp}] {event} :: {detail}\n"
    with open(config.AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line)


def read_recent(n: int = 100):
    """Return the last n log lines, newest first."""
    if not config.AUDIT_LOG_FILE.exists():
        return []
    with open(config.AUDIT_LOG_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return list(reversed(lines[-n:]))
