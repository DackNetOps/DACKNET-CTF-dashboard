"""
DackNet-Ops CTF Lab Dashboard
==============================
A single Flask app that brings John the Ripper, Medusa, and an ARP MITM
teaching demo under one authenticated dashboard, hard-scoped to a
configurable lab network (see config.py / modules/safety.py).

Run:
    pip install -r requirements.txt
    python app.py

Then open http://127.0.0.1:5000 and log in with the password set via the
DACKNET_PASSWORD environment variable (see README.md and .env.example).
"""

import functools
import os
from pathlib import Path

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_from_directory,
)
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

import config
from modules import audit_log, safety, john_module, medusa_module, mitm_module

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

PASSWORD_HASH = generate_password_hash(config.DEFAULT_PASSWORD)

config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
config.WORDLIST_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        pw = request.form.get("password", "")
        if check_password_hash(PASSWORD_HASH, pw):
            session["authenticated"] = True
            audit_log.log("LOGIN_OK", request.remote_addr)
            return redirect(url_for("dashboard"))
        audit_log.log("LOGIN_FAIL", request.remote_addr)
        flash("Incorrect password.", "error")
    return render_template("login.html", brand=config.BRAND)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/")
@login_required
def dashboard():
    status = {
        "john": john_module.is_installed(),
        "medusa": medusa_module.is_installed(),
        "mitm": mitm_module.is_available(),
    }
    return render_template(
        "dashboard.html", brand=config.BRAND, status=status,
        lab_networks=safety.allowed_networks(),
    )


# ---------------------------------------------------------------------------
# John the Ripper
# ---------------------------------------------------------------------------
@app.route("/john", methods=["GET", "POST"])
@login_required
def john_view():
    output = None
    if request.method == "POST":
        hash_file = request.files.get("hash_file")
        wordlist_file = request.files.get("wordlist_file")
        format_hint = request.form.get("format_hint") or None

        if not hash_file or hash_file.filename == "":
            flash("Upload a hash file you own (e.g. an extracted shadow/hash dump).", "error")
            return redirect(url_for("john_view"))

        hash_path = config.UPLOAD_DIR / secure_filename(hash_file.filename)
        hash_file.save(hash_path)

        wordlist_path = None
        if wordlist_file and wordlist_file.filename:
            wordlist_path = config.WORDLIST_DIR / secure_filename(wordlist_file.filename)
            wordlist_file.save(wordlist_path)

        success, output = john_module.run_crack(
            str(hash_path), str(wordlist_path) if wordlist_path else None, format_hint
        )
        flash("Run complete." if success else "Run failed — see output.", "ok" if success else "error")

    return render_template(
        "john.html", brand=config.BRAND, output=output,
        installed=john_module.is_installed(),
    )


# ---------------------------------------------------------------------------
# Medusa
# ---------------------------------------------------------------------------
@app.route("/medusa", methods=["GET", "POST"])
@login_required
def medusa_view():
    output = None
    if request.method == "POST":
        host = request.form.get("host", "").strip()
        service = request.form.get("service", "ssh").strip()
        threads = int(request.form.get("threads", 4) or 4)
        confirmed = request.form.get("confirm_authorized") == "on"

        user_file = request.files.get("user_file")
        pass_file = request.files.get("pass_file")

        if not host or not user_file or not pass_file:
            flash("Host, a usernames file, and a passwords file are all required.", "error")
            return redirect(url_for("medusa_view"))

        user_path = config.UPLOAD_DIR / secure_filename(user_file.filename)
        pass_path = config.UPLOAD_DIR / secure_filename(pass_file.filename)
        user_file.save(user_path)
        pass_file.save(pass_path)

        success, output = medusa_module.run_bruteforce(
            host, service, str(user_path), str(pass_path), confirmed, threads
        )
        flash("Run complete." if success else "Run blocked or failed — see output.",
              "ok" if success else "error")

    return render_template(
        "medusa.html", brand=config.BRAND, output=output,
        installed=medusa_module.is_installed(),
        lab_networks=safety.allowed_networks(),
    )


# ---------------------------------------------------------------------------
# MITM demo
# ---------------------------------------------------------------------------
@app.route("/mitm", methods=["GET", "POST"])
@login_required
def mitm_view():
    message = None
    session_id = session.get("mitm_session_id")

    if request.method == "POST":
        action = request.form.get("action")

        if action == "start":
            victim_ip = request.form.get("victim_ip", "").strip()
            gateway_ip = request.form.get("gateway_ip", "").strip()
            duration = int(request.form.get("duration", 60) or 60)
            confirmed = request.form.get("confirm_authorized") == "on"

            ok, message, new_session_id = mitm_module.start_demo(
                victim_ip, gateway_ip, duration, confirmed
            )
            if ok:
                session["mitm_session_id"] = new_session_id
                session_id = new_session_id
            flash(message, "ok" if ok else "error")

        elif action == "stop" and session_id:
            ok, message = mitm_module.stop_demo(session_id)
            flash(message, "ok" if ok else "error")

    status = mitm_module.session_status(session_id) if session_id else None

    return render_template(
        "mitm.html", brand=config.BRAND, status=status,
        available=mitm_module.is_available(),
        lab_networks=safety.allowed_networks(),
    )


@app.route("/mitm/status")
@login_required
def mitm_status():
    """Lightweight JSON poll endpoint for the live packet counter."""
    session_id = session.get("mitm_session_id")
    status = mitm_module.session_status(session_id) if session_id else None
    return status or {"running": False}


# ---------------------------------------------------------------------------
# Audit log viewer
# ---------------------------------------------------------------------------
@app.route("/logs")
@login_required
def logs_view():
    entries = audit_log.read_recent(200)
    return render_template("logs.html", brand=config.BRAND, entries=entries)


if __name__ == "__main__":
    print(f"\n  {config.BRAND['name']} CTF Lab Dashboard")
    print(f"  Lab scope: {', '.join(safety.allowed_networks())}")
    print("  Login with the password set in DACKNET_PASSWORD (see README.md)\n")
    app.run(host="127.0.0.1", port=5000, debug=False)
