# DackNet-Ops — CTF Lab Dashboard

A single Flask dashboard that brings three classic security-training
tools under one authenticated UI, themed to the DackNet-Ops brand:

- **Password Cracking** — a wrapper around [John the Ripper](https://www.openwall.com/john/) for hash files you've pulled from your own lab systems.
- **Login Brute-Force** — a wrapper around [Medusa](https://github.com/jmk-foofus/medusa) for credential-spraying a service on a lab host.
- **MITM Demo** — a time-capped ARP-spoofing demonstration (via [scapy](https://scapy.net/)) that shows how unauthenticated ARP lets a host intercept traffic between two other hosts on the same segment, with automatic ARP-table restoration.

## ⚠️ Scope and legal use — read first

This is a **training-lab tool**, not a general attack platform:

- Every action that touches a network target passes through one
  function, `modules/safety.py`, which blocks anything outside the
  CIDR ranges in `config.py` / `lab_data/lab_targets.json`. By default
  that's `192.168.56.0/24`, `10.10.10.0/24`, and `127.0.0.1` — common
  private ranges for a local VirtualBox/VMware lab, GNS3/EVE-NG lab,
  or HTB/THM-style practice box.
- Running these tools against any system you don't own and don't have
  explicit written authorization to test is illegal in most
  jurisdictions (e.g. the U.S. Computer Fraud and Abuse Act, UK
  Computer Misuse Act), regardless of what this tool lets you type
  into a form.
- Every run — successful, blocked, or failed — is written to
  `logs/audit.log`.
- Only point this at machines **you** control: a Metasploitable VM,
  DVWA, your own lab subnet, etc.

## Setup

```bash
git clone <your-fork-url>
cd dacknetops-ctf-dashboard
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Install the underlying tools on your lab machine:

```bash
# Debian/Ubuntu/Kali
sudo apt install john medusa
```

(scapy's ARP demo needs raw-socket access — run the app with `sudo` or
grant the Python interpreter `CAP_NET_RAW`/`CAP_NET_ADMIN` if you want
the MITM module to work; the other two tools don't need elevated
privileges.)

Set your own login password and secret key before running this for
anyone other than yourself:

```bash
cp .env.example .env
# edit .env, then:
export $(cat .env | xargs)
```

If you skip this, the dashboard falls back to the default password
baked into `config.py` for local convenience — **change it** before
pushing this repo anywhere public, and never commit a real `.env`.

## Run

```bash
python app.py
```

Open `http://127.0.0.1:5000`, log in, and use the sidebar to reach
each tool. The Overview page shows whether `john`/`medusa`/`scapy` are
detected on this machine.

## Adding your own lab targets

Edit `lab_data/lab_targets.json`:

```json
{
  "networks": ["192.168.100.0/24"]
}
```

Any CIDR range you add there is unioned with the defaults in
`config.py`. There is no in-app way to bypass this list — it's the
single choke point every tool module calls before running anything.

## Project layout

```
app.py                  Flask routes, auth, wiring
config.py                Branding, lab scope, paths
modules/
  safety.py              The scope/consent gate — read this first
  audit_log.py           Plain-text audit trail
  john_module.py          John the Ripper wrapper
  medusa_module.py        Medusa wrapper
  mitm_module.py           ARP-spoof teaching demo
templates/                Jinja2 templates (dark/green brand theme)
static/css/style.css      Brand styling
static/img/logo.png       DackNet-Ops logo
lab_data/                 Uploaded hash/user/pass files, lab target list
logs/audit.log            Every action, timestamped
```

## License

MIT — use it, fork it, adapt it for your own training labs. See
`LICENSE` if you add one before publishing.
