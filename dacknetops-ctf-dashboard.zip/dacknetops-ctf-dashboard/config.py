"""
config.py
---------
Central configuration for the DackNet-Ops CTF Lab Dashboard.

IMPORTANT — READ THIS BEFORE USE
=================================
This dashboard is a TRAINING-LAB front end for well-known security tools
(John the Ripper, Medusa) and a teaching demo for ARP-based MITM concepts.

It is hard-restricted so it can only point those tools at hosts inside
LAB_ALLOWED_NETWORKS below. That list defaults to private, non-routable
ranges typically used for local CTF labs (e.g. a Metasploitable VM on a
VirtualBox host-only adapter). Every action is also logged to
logs/audit.log.

Nothing in this project will let a user run these tools against a target
outside the configured lab ranges — the IP/host check in
modules/safety.py is not a suggestion, it is enforced before any
subprocess is launched.
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Branding — colors pulled from the DackNet-Ops logo
# ---------------------------------------------------------------------------
BRAND = {
    "name": "DackNet-Ops",
    "tagline": "HACK · DEFEND · DOMINATE",
    "bg": "#07090a",          # near-black background from the logo
    "panel": "#0d1210",       # slightly lifted panel background
    "green": "#4CFF3C",       # primary neon green (the "N" in the logo)
    "green_dim": "#1F7A1F",   # muted green for borders/secondary text
    "white": "#F2F3F0",       # off-white (the "D" in the logo)
    "danger": "#FF4C4C",
}

# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------
# The dashboard password is read from the DACKNET_PASSWORD environment
# variable. A default is provided ONLY so the app runs out of the box for
# local lab use — change it before you expose this to anyone else, and
# never commit a real password to a public repo. See README.md.
DEFAULT_PASSWORD = os.environ.get("DACKNET_PASSWORD", "Dacknet@4631")

SECRET_KEY = os.environ.get("DACKNET_SECRET_KEY", os.urandom(24).hex())

# ---------------------------------------------------------------------------
# Lab scope — the ONLY networks these tools are allowed to touch
# ---------------------------------------------------------------------------
# Add your own lab/VM subnets here. Keep this to private, non-routable
# ranges that you control (your own VirtualBox/VMware host-only network,
# a GNS3/EVE-NG lab, your own home lab, Metasploitable, DVWA, etc).
LAB_ALLOWED_NETWORKS = [
    "192.168.56.0/24",   # common VirtualBox host-only default
    "10.10.10.0/24",     # common HTB/THM-style lab range
    "127.0.0.1/32",      # localhost, for dry-run testing
]

# Can be overridden/extended at runtime via lab_data/lab_targets.json
LAB_TARGETS_FILE = BASE_DIR / "lab_data" / "lab_targets.json"

AUDIT_LOG_FILE = BASE_DIR / "logs" / "audit.log"

# ---------------------------------------------------------------------------
# External tool binaries — the dashboard shells out to the real tools.
# Install them on your lab machine (see README.md); the dashboard will
# tell you if one is missing rather than failing silently.
# ---------------------------------------------------------------------------
JOHN_BIN = os.environ.get("JOHN_BIN", "john")
MEDUSA_BIN = os.environ.get("MEDUSA_BIN", "medusa")

UPLOAD_DIR = BASE_DIR / "lab_data" / "uploads"
WORDLIST_DIR = BASE_DIR / "lab_data" / "wordlists"
